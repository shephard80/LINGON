SET @domain_name = "2web.se";
SET @username = "sebastian";
SET @password = "ncc17015428";

SELECT @salt := FLOOR(RAND() * 0xFFFFFFFF) AS salt;

INSERT INTO `contact_data` (`username`, `password`, `salt`, `firstname`, `lastname`, `organization`, `orgnr`, `userType`, `address1`, `address2`, `city`, `zip`, `country`, `phone`, `fax`, `email`) VALUES
(CONCAT(@username, '@', @domain_name), SHA2(CONCAT(@password, @salt), 256), @salt, 'Generic', 'User', '', '00000000-0000', '0', 'Rocky Road 123', NULL, 'Testtown', '123 45', 'Sweden', '000-000 00 00', NULL, CONCAT(@username, '@', @domain_name));

SET @contact_id = LAST_INSERT_ID();

SET @domain_id = (SELECT domain_id FROM domain_data WHERE domain_name = @domain_name);

INSERT INTO `domain_contacts` (`domain_data_id`, `contact_data_id`) VALUES
(@domain_id, @contact_id);
